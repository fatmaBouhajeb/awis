<p class="mt-5 mb-3 text-muted">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH /Users/fatmabouhajeb/Desktop/awais/resources/views/auth/partials/copy.blade.php ENDPATH**/ ?>